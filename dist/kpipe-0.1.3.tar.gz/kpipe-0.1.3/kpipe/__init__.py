__version__ = '0.1.3'

from kpipe.KPipe import KPipe
